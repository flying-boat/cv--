import cv2 as cv
import numpy as np
from scipy.signal import butter, lfilter, freqz
import matplotlib.pyplot as plt
from PIL import Image

img = cv.imread(r'C:\Users\TechIts\Desktop\ex3\2-1.jpg', 0)
rows, cols = img.shape
crow,ccol = int(rows/2), int(cols/2)
im = np.zeros((rows, cols), np.uint8)
im[crow:crow+120, ccol-120:ccol+85] = img[crow:crow+120, ccol-120:ccol+85]
im[crow+120:crow+150, ccol-120:ccol+30] = img[crow+120:crow+150, ccol-120:ccol+30]
img[crow:crow+120, ccol-120:ccol+85] = 0
img[crow+120:crow+150, ccol-120:ccol+30] = 0
dft = cv.dft(np.float32(im), flags = cv.DFT_COMPLEX_OUTPUT)
fshift = np.fft.fftshift(dft)

rows, cols = im.shape
crow,ccol = int(rows/2), int(cols/2)
mask = np.zeros((rows, cols, 2))
mask[crow-80:crow+80, ccol-80:ccol+80] = 1

f = fshift * mask

ishift = np.fft.ifftshift(f)
iimg = cv.idft(ishift)
res = cv.magnitude(iimg[:,:,0], iimg[:,:,1])
res = (res-res.min())/(res.max()-res.min())
x = len(res)
y = len(res[0])
for i in range(x):
    for j in range(y):
        res[i][j] *= 255
res = res.astype(np.uint8)

cv.imshow('im', img+res)
cv.waitKey(0)