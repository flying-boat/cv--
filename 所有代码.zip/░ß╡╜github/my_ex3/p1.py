import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt
im = cv.imread(r'C:\Users\TechIts\Desktop\ex3\1-1.jpg', 0)
dft = cv.dft(np.float32(im), flags = cv.DFT_COMPLEX_OUTPUT)
fshift = np.fft.fftshift(dft)

rows, cols = im.shape
crow,ccol = int(rows/2), int(cols/2) #中心位置
print(crow,ccol)
mask = np.ones((rows, cols, 2), np.uint8)
mask[crow-47:crow-23, ccol+18:ccol+39] = 0#涂频谱中的亮点
mask[crow+35:crow+52, ccol+22:ccol+36] = 0
mask[crow-45:crow-30, ccol-36:ccol-18] = 0
mask[crow+35:crow+52, ccol-37:ccol-18] = 0
f = fshift * mask

ishift = np.fft.ifftshift(f)
iimg = cv.idft(ishift)
res = cv.magnitude(iimg[:,:,0], iimg[:,:,1])

plt.subplot(121), plt.imshow(im, 'gray'), plt.title('Original Image')
plt.axis('off')
plt.subplot(122), plt.imshow(res, 'gray'), plt.title('Result Image')
plt.axis('off')
plt.show()

dft = cv.dft(np.float32(iimg), flags = cv.DFT_COMPLEX_OUTPUT)
dftShift = np.fft.fftshift(dft)
result = 20*np.log(cv.magnitude(dftShift[:,:,0], dftShift[:,:,1]))
plt.imshow(result, cmap = 'gray')
plt.title('result')
plt.axis('off')
plt.show()
