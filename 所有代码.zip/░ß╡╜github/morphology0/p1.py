import cv2
img = cv2.imread(r'C:\Users\TechIts\Desktop\9.1\wdg2ero1.jpg',0)
#原图像
cv2.imshow("Origin", img)
#OpenCV定义的结构元素
kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(5, 5))
#5X5腐蚀图像
eroded = cv2.erode(img,kernel)
cv2.imshow("Eroded Image 5X5",eroded)

kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(20, 20))
#20X20腐蚀图像
eroded = cv2.erode(img,kernel)
cv2.imshow("Eroded Image 20X20",eroded)

kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(50, 50))
#50X50腐蚀图像
eroded = cv2.erode(img,kernel)
cv2.imshow("Eroded Image 50X50",eroded)
cv2.waitKey(0)