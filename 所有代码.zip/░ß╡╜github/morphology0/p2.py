import cv2
img = cv2.imread(r'C:\Users\TechIts\Desktop\9.1\wdg2thr3.jpg',0)
#原图像
cv2.imshow("Origin", img)
kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(5, 5))
#膨胀图像
dilated = cv2.dilate(img,kernel)
#显示膨胀后的图像
cv2.imshow("Dilated Image 5X5",dilated)

kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(20, 20))
dilated = cv2.dilate(img,kernel)
cv2.imshow("Dilated Image 20X20",dilated)

kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(40, 40))
dilated = cv2.dilate(img,kernel)
cv2.imshow("Dilated Image 30X30",dilated)
cv2.waitKey(0)
cv2.destroyAllWindows()