import cv2
img = cv2.imread(r'C:\Users\TechIts\Desktop\9.1\blb1.jpg',0)
#原图像
cv2.imshow("Origin", img)
#开操作
kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(7, 7))
eroded = cv2.erode(img,kernel)
dilated = cv2.dilate(eroded,kernel)
cv2.imshow("Opened Image",dilated)

#闭操作
kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(12, 12))
dilated = cv2.dilate(img,kernel)
eroded = cv2.erode(dilated,kernel)
cv2.imshow("Closed Image",eroded)
cv2.waitKey(0)
cv2.destroyAllWindows()