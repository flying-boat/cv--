import numpy as np
from PIL import Image
import cv2 as cv
from skimage import exposure
I = cv.imread(r'C:\Users\TechIts\Desktop\blur images\body_x_ray.jpg',0)
x, y = I.shape
ori_pad = np.pad(I,((1,1),(1,1)),'edge')

t1 = np.array([[0,-1,-2],[1,9,-3],[0,-1,-2]])
img = np.zeros((x, y),int)
for i in range(x):
    for j in range(y):
        img[i,j]=np.sum(ori_pad[i:i+3,j:j+3]*t1)
        if img[i,j] < 0:
            img[i,j] = 0
        if img[i,j] >255:
            img[i,j] = 255
img = img.astype('uint8')
I = cv.equalizeHist(img)
ans = Image.fromarray(I)
ans.show()