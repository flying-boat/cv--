import numpy as np
from PIL import Image
ori = Image.open(r'C:\Users\TechIts\Desktop\blur images\flower1 blur.jpg')
ori_gray = ori.convert('L')

I = np.array(ori_gray)
x, y = I.shape

ori_pad = np.pad(ori_gray,((1,1),(1,1)),'edge')

t1 = np.array([[0,-1,0],[-1,5,-1],[0,-1,0]])
img = np.zeros((x, y))
for i in range(1, x-2):
    for j in range(1, y-2):
        img[i,j]=np.sum(ori_pad[i:i+3,j:j+3]*t1)
        if img[i,j] < 0:
            img[i,j] = 0
ans = Image.fromarray(img)
ans.show()
