import numpy as np
from PIL import Image
ori = Image.open(r'C:\Users\TechIts\Desktop\blur images\x-rayblog-gausian blur d4.jpg')
ori_gray = ori.convert('L')

I = np.array(ori_gray)
x, y = I.shape

ori_pad = np.pad(ori_gray,((1,1),(1,1)),'edge')

t1 = np.array([[1,0,-1],[2,0,-2],[1,0,-1]])
img1 = np.zeros((x, y))
for i in range(1, x-2):
    for j in range(1, y-2):
        img1[i,j]=np.sum(ori_pad[i:i+3,j:j+3]*t1)
        if img1[i,j] < 0:
            img1[i,j] = -img1[i,j]
t2 = np.array([[1,2,1],[0,0,0],[-1,-2,-1]])
img2 = np.zeros((x, y))
for i in range(1, x-2):
    for j in range(1, y-2):
        img2[i,j]=np.sum(ori_pad[i:i+3,j:j+3]*t2)
        if img2[i,j] < 0:
            img2[i,j] = -img2[i,j]
img = img1+img2
ans = Image.fromarray(img)
ans.show()

