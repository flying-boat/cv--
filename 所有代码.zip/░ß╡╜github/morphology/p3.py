import cv2
img = cv2.imread(r'C:\Users\TechIts\Desktop\9.1\black.jpg',0)
#原图像
cv2.imshow("Origin", img)
#开操作
kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(50, 50))
eroded = cv2.erode(img,kernel)
dilated = cv2.dilate(eroded,kernel)
ans = 255-img+dilated
cv2.imshow("Opened Image",ans)

cv2.waitKey(0)
cv2.destroyAllWindows()