import cv2
img = cv2.imread(r'C:\Users\TechIts\Desktop\9.1\big_yun.png',0)
#原图像
cv2.imshow("Origin", img)
#开操作
kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5, 5))
print(kernel)
eroded = cv2.erode(img,kernel)
dilated = cv2.dilate(eroded,kernel)
cv2.imshow("Opened Image",dilated)

cv2.waitKey(0)
cv2.destroyAllWindows()