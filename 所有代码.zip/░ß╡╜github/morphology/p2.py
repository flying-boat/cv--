import cv2 as cv

src = cv.imread(r"C:\Users\TechIts\Desktop\9.1\find_l.bmp")
image = cv.cvtColor(src, cv.COLOR_RGB2GRAY)  	#二值化函数
cv.threshold(image, 100, 255, 0, image)
image = 255-image
cv.imshow("image",image)
#找到一个l的模板
model = image[65:79, 146:149]
for i in range(len(model)):
    for j in range(3):
        if model[i][j]==255:
            model[i][j] = 1
print(model)
eroded = cv.erode(image,model)
dilated = cv.dilate(eroded,model)
cv.imshow("Opened Image",dilated)

cv.waitKey(0)
cv.destroyAllWindows()