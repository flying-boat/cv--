import cv2 as cv
import numpy as np
def detect_circle_demo(image):
    pass
    circle = cv.HoughCircles(image, cv.HOUGH_GRADIENT,
                             1, 30, param1=40, param2=20, minRadius=12, maxRadius=35)
    print(len(circle[0]))
    if not circle is None:
        circle = np.uint16(np.around(circle))
        for i in circle[0, :]:
            cv.circle(image, (i[0], i[1]), i[2], (0, 255, 0), 1)
            cv.imshow("circle", image)
src = cv.imread(r'C:\Users\TechIts\Desktop\6-im_fenge\2-1.jpg', cv.IMREAD_GRAYSCALE)
src = cv.resize(src, None, fx=0.5, fy=0.5, interpolation=cv.INTER_CUBIC)
dst = cv.equalizeHist(src)

detect_circle_demo(dst)
cv.waitKey(0)
