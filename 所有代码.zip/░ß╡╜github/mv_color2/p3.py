import cv2 as cv
import numpy as np

src = cv.imread(r'C:\Users\TechIts\Desktop\6-im_fenge\3.jpg', cv.IMREAD_GRAYSCALE)
ret, thresh = cv.threshold(src, 130, 255, cv.THRESH_TOZERO)
cv.imshow("Image-New", thresh)
cv.waitKey()
cv.destroyAllWindows()