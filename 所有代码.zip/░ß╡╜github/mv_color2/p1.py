import cv2
import numpy as np
frame = cv2.imread(r'C:\Users\TechIts\Desktop\6-im_fenge\1-1.jpg')

# 将色彩空间从BGR转为HSV
hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

# 定义蓝色在HSV色彩空间中的范围
lower_blue = np.array([0,0,150])
upper_blue = np.array([255,255,255])

# 根据阈值生成掩膜
mask = cv2.inRange(hsv, lower_blue, upper_blue)

# 将掩膜与原图像进行位与运算
res = cv2.bitwise_and(frame, frame, mask=mask)

cv2.imshow('res',res)
cv2.waitKey(0)
cv2.destroyAllWindows()
