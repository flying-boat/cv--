from PIL import Image
import numpy as np
import cv2 as cv

im = Image.open(r'C:\Users\TechIts\Desktop\6 彩色图像\image1.bmp')
im = np.asarray(im)
im_hsv = cv.cvtColor(im, cv.COLOR_RGB2HSV)#转化到HSV空间，该空间的H、S与HSI一致
im_hsv2 = cv.cvtColor(im, cv.COLOR_RGB2HSV)
mask = 1/625*np.ones((25, 25))

im_h = cv.filter2D(im_hsv[:,:,0], -1, mask)#均值滤波
im_hsv[:,:,0] = im_h
ans1 = cv.cvtColor(im_hsv, cv.COLOR_HSV2RGB)#变回去
cv.imshow('H', ans1)
cv.waitKey(0)

im_s = cv.filter2D(im_hsv2[:,:,1], -1, mask)
im_hsv2[:,:,1] = im_s
ans2 = cv.cvtColor(im_hsv2, cv.COLOR_HSV2RGB)
cv.imshow('S', ans2)
cv.waitKey(0)
