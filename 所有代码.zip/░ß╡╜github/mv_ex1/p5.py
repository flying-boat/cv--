from PIL import Image
import cv2 as cv

im = cv.imread('C:\\Users\\TechIts\\Desktop\\ex1_p\\fishX-rays_lowContrast.jpg', 0)
ans = cv.equalizeHist(im)
im = Image.fromarray(ans)
im = im.convert('L')
im.show()