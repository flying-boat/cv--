from PIL import Image
import numpy as np
def filt(a):
    x, y = a.shape
    b = np.zeros((x, y))
    for i in range(2, x-2):
        for j in range(2, y-2):
            for k in range(-2, 3):
                for o in range(-2, 3):
                     b[i][j]+=a[i+k][j+o]
            b[i][j]/=25
    return b
def rslt(x):
    im = Image.fromarray(x)
    im = im.convert('L')
    im.show()

im = Image.open('C:\\Users\\TechIts\\Desktop\\ex1_p\\图2.bmp')
im = im.convert('L')
I = np.array(im)
x, y = I.shape
#0填充
I1 = np.zeros((x+4,y+4))
for i in range(2, x+2):
    for j in range(2, y+2):
        I1[i][j] = I[i-2][j-2]
ans = filt(I1)
rslt(ans)
#中心填充
center = I[199][199]/4+I[200][199]/4+I[199][200]/4+I[200][200]/4
I2 = I1
for i in range(x+4):
    for j in range(2):
        I2[i][j] = center
for i in range(x+4):
    for j in range(y+2, y+4):
        I2[i][j] = center
for i in range(2):
    for j in range(2,y+2):
        I2[i][j] = center
for i in range(x+2, x+4):
    for j in range(2,y+2):
        I2[i][j] = center
ans2 = filt(I2)
rslt(ans2)
#边缘填充
I3 = I1
for i in range(2, x+2):
    for j in range(2):
        I3[i][j] = I1[i][2]
for i in range(2, x+2):
    for j in range(y+2, y+4):
        I3[i][j] = I1[i][y+1]
for i in range(2):
    for j in range(2, y+2):
        I3[i][j] = I1[2][j]
for i in range(x+2,x+4):
    for j in range(2, y+2):
        I3[i][j] = I1[x+1][j]
for i in range(2):
    for j in range(2):
        I3[i][j] = I1[2][2]
for i in range(x+2,x+4):
    for j in range(y+2,y+4):
        I3[i][j] = I1[x+1][y+1]
for i in range(x+2,x+4):
    for j in range(2):
        I3[i][j] = I1[x+1][2]
for i in range(2):
    for j in range(y+2,y+4):
        I3[i][j] = I1[2][y+1]
ans3 = filt(I3)
rslt(ans3)