from PIL import Image
import numpy as np
def re(path):
    im = Image.open(path)
    return im
path_list = ['C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise1.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise2.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise3.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise4.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise5.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise6.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise7.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise8.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise9.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise10.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise11.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise12.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise13.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise14.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise15.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise16.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise17.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise18.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise19.jpg',
             'C:\\Users\\TechIts\\Desktop\\ex1_p\\image_noise20.jpg']
imt = re(path_list[0])
imt = np.array(imt)
x, y = imt.shape
ans = np.zeros((x, y ))
for i in path_list:
    im = re(i)
    I = np.array(im)
    ans+=I
ans//=20
im = Image.fromarray(ans)
im = im.convert('L')
im.show()