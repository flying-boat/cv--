from PIL import Image
import numpy as np
import cv2 as cv
def filt(a):
    x, y = a.shape
    b = np.zeros((x, y))
    for i in range(1, x-1):
        for j in range(1, y-1):
            for k in range(-1, 2):
                for o in range(-1, 2):
                     b[i][j]+=a[i+k][j+o]
            b[i][j]/=9
    return b
def rslt(x):
    im = Image.fromarray(x)
    im = im.convert('L')
    im.show()

I = cv.imread('C:\\Users\\TechIts\\Desktop\\ex1_p\\image_gaussian_noise.jpg',
               cv.IMREAD_GRAYSCALE)
img_median = cv.medianBlur(I, 3)
rslt(img_median)
x, y = I.shape

I1 = np.zeros((x+2,y+2))
for i in range(1, x+1):
    for j in range(1, y+1):
        I1[i][j] = I[i-1][j-1]
I2 = I1
for i in range(1, x+1):
    for j in range(1):
        I2[i][j] = I1[i][1]
for i in range(1, x+1):
    for j in range(y+1, y+2):
        I2[i][j] = I1[i][y]
for i in range(1):
    for j in range(1, y+1):
        I2[i][j] = I1[1][j]
for i in range(x+1, x+2):
    for j in range(1, y+1):
        I2[i][j] = I1[x][j]
ans = filt(I2)
rslt(ans)