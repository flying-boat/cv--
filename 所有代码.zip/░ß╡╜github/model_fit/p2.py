import cv2
target = cv2.imread(r"C:\Users\TechIts\Desktop\10\cats.jpg")
template = cv2.imread(r"C:\Users\TechIts\Desktop\10\cats_template.jpg")
theight, twidth = template.shape[:2]

result = cv2.matchTemplate(target,template,cv2.TM_SQDIFF_NORMED)
cv2.normalize(result, result, 0, 1, cv2.NORM_MINMAX, -1)
min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
strmin_val = str(min_val)

#绘制矩形边框，将匹配区域标注出来
#min_loc：矩形定点
#(min_loc[0]+twidth,min_loc[1]+theight)：矩形的宽高
#(0,0,225)：矩形的边框颜色；2：矩形边框宽度
cv2.rectangle(target,min_loc,(min_loc[0]+twidth,min_loc[1]+theight),(0,0,225),2)

cv2.imshow("result",target)
cv2.waitKey(0)
cv2.destroyAllWindows()